# Pesquisa sobre Padrão MVC
Pesquisa da matéria de Orientação a Objetos do semestre 2022.1

Este repositória foi criado com o objetivo de servir como exemplo para a pesquisa sobre MVC, passado pelo professor

Projeto Composto dos Membros :
GRUPO 01

[Danilo Carvalho Antunes](https://github.com/Danilo-Carvalho-Antunes) - 211039312
<br>
[Gabriel Ferreira da Silva](https://github.com/oo7gabriel) - 200018060
<br>
[Paulo Henrique Rossi de Borba](https://github.com/paulohborba) - 190094273

O enunciado desse dever pode ser encontrado no link abaixo:

[Enunciado](https://github.com/andrelanna/fga0158/tree/master/trabalhoPratico/entrega3)
