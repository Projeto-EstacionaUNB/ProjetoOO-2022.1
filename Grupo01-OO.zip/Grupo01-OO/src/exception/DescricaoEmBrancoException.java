package exception;

public class DescricaoEmBrancoException extends Exception{
}
