package exception;

public class ObjetoNãoEncontradoException extends Exception{
}
