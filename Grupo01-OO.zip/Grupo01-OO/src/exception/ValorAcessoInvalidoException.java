package exception;

public class ValorAcessoInvalidoException extends Exception{
}
